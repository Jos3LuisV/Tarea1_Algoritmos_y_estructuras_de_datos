﻿namespace GestionVehiculos
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstVehiculos = new System.Windows.Forms.ListBox();
            this.lblDetalles = new System.Windows.Forms.Label();
            this.btnAgregarCoche = new System.Windows.Forms.Button();
            this.btnAgregarMoto = new System.Windows.Forms.Button();
            this.btnMostrarInfo = new System.Windows.Forms.Button();
            this.btnArrancar = new System.Windows.Forms.Button();
            this.btnAcelerar = new System.Windows.Forms.Button();
            this.btnFrenar = new System.Windows.Forms.Button();
            this.btnBocina = new System.Windows.Forms.Button();
            this.btnReparar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstVehiculos
            // 
            this.lstVehiculos.FormattingEnabled = true;
            this.lstVehiculos.ItemHeight = 16;
            this.lstVehiculos.Location = new System.Drawing.Point(551, 25);
            this.lstVehiculos.Name = "lstVehiculos";
            this.lstVehiculos.Size = new System.Drawing.Size(277, 148);
            this.lstVehiculos.TabIndex = 0;
            this.lstVehiculos.SelectedIndexChanged += new System.EventHandler(this.lstVehiculos_SelectedIndexChanged);
            // 
            // lblDetalles
            // 
            this.lblDetalles.AutoSize = true;
            this.lblDetalles.Location = new System.Drawing.Point(517, 218);
            this.lblDetalles.Name = "lblDetalles";
            this.lblDetalles.Size = new System.Drawing.Size(0, 16);
            this.lblDetalles.TabIndex = 1;
            // 
            // btnAgregarCoche
            // 
            this.btnAgregarCoche.Location = new System.Drawing.Point(23, 23);
            this.btnAgregarCoche.Name = "btnAgregarCoche";
            this.btnAgregarCoche.Size = new System.Drawing.Size(106, 44);
            this.btnAgregarCoche.TabIndex = 2;
            this.btnAgregarCoche.Text = "Agregar coche";
            this.btnAgregarCoche.UseVisualStyleBackColor = true;
            this.btnAgregarCoche.Click += new System.EventHandler(this.btnAgregarCoche_Click_1);
            // 
            // btnAgregarMoto
            // 
            this.btnAgregarMoto.Location = new System.Drawing.Point(171, 23);
            this.btnAgregarMoto.Name = "btnAgregarMoto";
            this.btnAgregarMoto.Size = new System.Drawing.Size(100, 49);
            this.btnAgregarMoto.TabIndex = 3;
            this.btnAgregarMoto.Text = "Agregar moto";
            this.btnAgregarMoto.UseVisualStyleBackColor = true;
            this.btnAgregarMoto.Click += new System.EventHandler(this.btnAgregarMoto_Click_1);
            // 
            // btnMostrarInfo
            // 
            this.btnMostrarInfo.Location = new System.Drawing.Point(306, 25);
            this.btnMostrarInfo.Name = "btnMostrarInfo";
            this.btnMostrarInfo.Size = new System.Drawing.Size(89, 41);
            this.btnMostrarInfo.TabIndex = 4;
            this.btnMostrarInfo.Text = "Mostrar info";
            this.btnMostrarInfo.UseVisualStyleBackColor = true;
            this.btnMostrarInfo.Click += new System.EventHandler(this.btnMostrarInfo_Click_1);
            // 
            // btnArrancar
            // 
            this.btnArrancar.Location = new System.Drawing.Point(42, 103);
            this.btnArrancar.Name = "btnArrancar";
            this.btnArrancar.Size = new System.Drawing.Size(87, 38);
            this.btnArrancar.TabIndex = 5;
            this.btnArrancar.Text = "Arrancar";
            this.btnArrancar.UseVisualStyleBackColor = true;
            this.btnArrancar.Click += new System.EventHandler(this.btnArrancar_Click_1);
            // 
            // btnAcelerar
            // 
            this.btnAcelerar.Location = new System.Drawing.Point(180, 97);
            this.btnAcelerar.Name = "btnAcelerar";
            this.btnAcelerar.Size = new System.Drawing.Size(82, 50);
            this.btnAcelerar.TabIndex = 6;
            this.btnAcelerar.Text = "Acelerar +10";
            this.btnAcelerar.UseVisualStyleBackColor = true;
            this.btnAcelerar.Click += new System.EventHandler(this.btnAcelerar_Click_1);
            // 
            // btnFrenar
            // 
            this.btnFrenar.Location = new System.Drawing.Point(303, 101);
            this.btnFrenar.Name = "btnFrenar";
            this.btnFrenar.Size = new System.Drawing.Size(92, 46);
            this.btnFrenar.TabIndex = 7;
            this.btnFrenar.Text = "Frenar";
            this.btnFrenar.UseVisualStyleBackColor = true;
            this.btnFrenar.Click += new System.EventHandler(this.btnFrenar_Click_1);
            // 
            // btnBocina
            // 
            this.btnBocina.Location = new System.Drawing.Point(42, 173);
            this.btnBocina.Name = "btnBocina";
            this.btnBocina.Size = new System.Drawing.Size(97, 51);
            this.btnBocina.TabIndex = 8;
            this.btnBocina.Text = "Tocar bocina";
            this.btnBocina.UseVisualStyleBackColor = true;
            this.btnBocina.Click += new System.EventHandler(this.btnBocina_Click_1);
            // 
            // btnReparar
            // 
            this.btnReparar.Location = new System.Drawing.Point(189, 181);
            this.btnReparar.Name = "btnReparar";
            this.btnReparar.Size = new System.Drawing.Size(82, 43);
            this.btnReparar.TabIndex = 9;
            this.btnReparar.Text = "Reparar";
            this.btnReparar.UseVisualStyleBackColor = true;
            this.btnReparar.Click += new System.EventHandler(this.btnReparar_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1146, 531);
            this.Controls.Add(this.btnReparar);
            this.Controls.Add(this.btnBocina);
            this.Controls.Add(this.btnFrenar);
            this.Controls.Add(this.btnAcelerar);
            this.Controls.Add(this.btnArrancar);
            this.Controls.Add(this.btnMostrarInfo);
            this.Controls.Add(this.btnAgregarMoto);
            this.Controls.Add(this.btnAgregarCoche);
            this.Controls.Add(this.lblDetalles);
            this.Controls.Add(this.lstVehiculos);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstVehiculos;
        private System.Windows.Forms.Label lblDetalles;
        private System.Windows.Forms.Button btnAgregarCoche;
        private System.Windows.Forms.Button btnAgregarMoto;
        private System.Windows.Forms.Button btnMostrarInfo;
        private System.Windows.Forms.Button btnArrancar;
        private System.Windows.Forms.Button btnAcelerar;
        private System.Windows.Forms.Button btnFrenar;
        private System.Windows.Forms.Button btnBocina;
        private System.Windows.Forms.Button btnReparar;
    }
}

