﻿using System.Collections.Generic;

namespace GestionVehiculos.Models
{
    public class Garage
    {
        private readonly List<Transporte> _vehiculos = new List<Transporte>();

        public IReadOnlyList<Transporte> Vehiculos => _vehiculos.AsReadOnly();

        public void Agregar(Transporte t) => _vehiculos.Add(t);

        public bool Remover(Transporte t) => _vehiculos.Remove(t);
    }
}
