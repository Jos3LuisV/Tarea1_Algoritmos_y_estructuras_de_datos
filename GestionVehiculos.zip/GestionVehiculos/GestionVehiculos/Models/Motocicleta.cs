﻿namespace GestionVehiculos.Models
{
    public class Motocicleta : Terrestre
    {
        public bool TieneSidecar { get; set; }

        public Motocicleta(string marca, int año, string matricula, int numRuedas, bool tieneSidecar)
            : base(marca, año, matricula, numRuedas)
        {
            TieneSidecar = tieneSidecar;
        }

        public override string MostrarInfo()
        {
            return $"Motocicleta: {Marca} ({Año}) - Matrícula: {Matricula} - Ruedas: {NumRuedas}" + (TieneSidecar ? " (con sidecar)" : "");
        }

        public override string TocarBocina()
        {
            return "¡Bip!";
        }
    }
}

