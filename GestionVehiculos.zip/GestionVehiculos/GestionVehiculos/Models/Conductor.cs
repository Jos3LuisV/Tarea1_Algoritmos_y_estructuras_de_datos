﻿namespace GestionVehiculos.Models
{
    public class Conductor
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }

        // Asociación con Transporte (el conductor puede tener un vehículo asignado).
        private Transporte _vehiculoAsignado;
        public Conductor(string nombre, int edad)
        {
            Nombre = nombre;
            Edad = edad;
        }

        public void AsignarVehiculo(Transporte t) => _vehiculoAsignado = t;

        public string MostrarEstado()
        {
            if (_vehiculoAsignado == null) return $"{Nombre} no tiene vehículo asignado.";
            return $"{Nombre} conduce {_vehiculoAsignado.MostrarInfo()}";
        }
    }
}

