﻿namespace GestionVehiculos.Models
{
    public interface IReparable
    {
        // Firma del método Reparar (no implementación).
        string Reparar();
    }
}

