﻿namespace GestionVehiculos.Models
{
    public abstract class Terrestre : Vehiculo
    {
        public int NumRuedas { get; set; }

        protected Terrestre(string marca, int año, string matricula, int numRuedas)
            : base(marca, año, matricula)
        {
            NumRuedas = numRuedas;
        }

        public override string MostrarInfo()
        {
            return base.MostrarInfo() + $", Ruedas: {NumRuedas}";
        }
    }
}

