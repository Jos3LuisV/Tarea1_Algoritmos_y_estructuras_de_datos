﻿namespace GestionVehiculos.Models
{
    public abstract class Vehiculo : Transporte
    {
        public string Matricula { get; set; }

        protected Vehiculo(string marca, int año, string matricula)
            : base(marca, año)
        {
            Matricula = matricula;
        }

        // Provee una implementacion base; las subclases pueden extenderla/override.
        public override string MostrarInfo()
        {
            return $"Vehículo: {Marca}, Año: {Año}, Matrícula: {Matricula}";
        }

        // Método abstracto que obliga a la implementación de la bocina.
        public abstract string TocarBocina();
    }
}

