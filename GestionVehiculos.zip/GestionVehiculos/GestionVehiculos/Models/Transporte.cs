﻿using System;

namespace GestionVehiculos.Models
{
    // Abstracción: clase base abstracta que define la interfaz mínima del transporte.
    public abstract class Transporte
    {
        public string Marca { get; set; }
        public int Año { get; set; }

        // Encapsulamiento: campo privado con propiedad pública de solo lectura (o protected set).
        private int _velocidad;
        public int Velocidad { get => _velocidad; protected set => _velocidad = value; }

        protected Transporte(string marca, int año)
        {
            Marca = marca;
            Año = año;
            _velocidad = 0;
        }

        // Método concreto (se comparte la implementación).
        public void Acelerar(int incremento)
        {
            if (incremento < 0) throw new ArgumentException("incremento debe ser >= 0");
            Velocidad += incremento;
        }

        public void Detener()
        {
            Velocidad = 0;
        }

        // Abstracción / polimorfismo: método abstracto que obliga a las subclases a implementarlo.
        public abstract string MostrarInfo();

        // Método virtual que puede ser sobrescrito — ejemplo de polimorfismo.
        public virtual void Arrancar()
        {
            Velocidad = 1;
        }

        public override string ToString() => $"{GetType().Name} - {Marca} ({Año})";
    }
}

