﻿namespace GestionVehiculos.Models
{
    public class Coche : Terrestre, IReparable
    {
        public string Modelo { get; set; }

        public Coche(string marca, int año, string matricula, int numRuedas, string modelo)
            : base(marca, año, matricula, numRuedas)
        {
            Modelo = modelo;
        }

        public override string MostrarInfo()
        {
            return $"Coche: {Marca} {Modelo} ({Año}) - Matrícula: {Matricula} - Ruedas: {NumRuedas} - Velocidad: {Velocidad} km/h";
        }

        public override string TocarBocina()
        {
            return "¡BEEP BEEP!";
        }

        public string Reparar()
        {
            return $"Reparando coche {Marca} {Modelo} (Matrícula {Matricula})";
        }
    }
}

