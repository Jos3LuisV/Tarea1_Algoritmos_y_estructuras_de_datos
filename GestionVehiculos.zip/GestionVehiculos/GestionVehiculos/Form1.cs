﻿using System;
using System.Linq;
using System.Windows.Forms;
using GestionVehiculos.Models;

namespace GestionVehiculos
{
    public partial class Form1 : Form
    {
        private readonly Garage _garage = new Garage();

        public Form1()
        {
            InitializeComponent();
            RefreshList();
        }

        private void RefreshList()
        {
            lstVehiculos.Items.Clear();
            foreach (var v in _garage.Vehiculos)
                lstVehiculos.Items.Add(v); // usa ToString() de Transporte
        }


        private void btnAgregarCoche_Click_1(object sender, EventArgs e)
        {
            var c = new Coche("Toyota", 2020, "ABC-123", 4, "Corolla");
            _garage.Agregar(c);
            RefreshList();
        }

        private void btnAgregarMoto_Click_1(object sender, EventArgs e)
        {
            var m = new Motocicleta("Honda", 2018, "MOTO-01", 2, false);
            _garage.Agregar(m);
            RefreshList();
        }

        private void btnMostrarInfo_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }
            lblDetalles.Text = sel.MostrarInfo();
        }

        private void btnArrancar_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }
            sel.Arrancar();
            lblDetalles.Text = sel.MostrarInfo();
        }

        private void btnAcelerar_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }
            sel.Acelerar(10); // demostración simple
            lblDetalles.Text = sel.MostrarInfo();
        }

        private void btnFrenar_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }
            sel.Detener();
            lblDetalles.Text = sel.MostrarInfo();
        }

        private void btnBocina_Click_1(object sender, EventArgs e)
        {
            var selVeh = lstVehiculos.SelectedItem as Vehiculo;
            if (selVeh == null) { MessageBox.Show("Seleccione un vehículo (debe ser tipo Vehículo)"); return; }
            MessageBox.Show(selVeh.TocarBocina());
        }

        private void btnReparar_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }

            if (sel is IReparable rep)
                MessageBox.Show(rep.Reparar());
            else
                MessageBox.Show("Este vehículo no implementa reparación (IReparable).");
        }

        private void lstVehiculos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}

