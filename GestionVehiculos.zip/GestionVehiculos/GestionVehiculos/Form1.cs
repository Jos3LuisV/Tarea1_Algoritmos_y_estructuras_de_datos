﻿using System;
using System.Windows.Forms;
using GestionVehiculos.Models;

namespace GestionVehiculos
{
    public partial class Form1 : Form
    {
        private readonly Garage _garage = new Garage();

        // Controles adicionales
        private TextBox txtConductor;
        private Label lblConductor;
        private Button btnAsignarConductor;
        private Button btnQuitarVehiculo; // Nuevo botón

        public Form1()
        {
            InitializeComponent();
            InicializarControlesAdicionales();
            RefreshList();
        }

        private void InicializarControlesAdicionales()
        {
            // Label del conductor
            lblConductor = new Label();
            lblConductor.Text = "Nombre del Conductor:";
            lblConductor.Location = new System.Drawing.Point(10, 250);
            lblConductor.AutoSize = false;
            lblConductor.Width = 140;
            this.Controls.Add(lblConductor);

            // TextBox Conductor
            txtConductor = new TextBox();
            txtConductor.Name = "txtConductor";
            txtConductor.Location = new System.Drawing.Point(150, 245);
            this.Controls.Add(txtConductor);

            // Botón Asignar Conductor
            btnAsignarConductor = new Button();
            btnAsignarConductor.Text = "Asignar Conductor";
            btnAsignarConductor.Location = new System.Drawing.Point(10, 280);
            btnAsignarConductor.Click += BtnAsignarConductor_Click;
            this.Controls.Add(btnAsignarConductor);

            // Botón Quitar Vehículo
            btnQuitarVehiculo = new Button();
            btnQuitarVehiculo.Text = "Quitar Vehículo";
            btnQuitarVehiculo.Location = new System.Drawing.Point(230, 150);
            btnQuitarVehiculo.Click += BtnQuitarVehiculo_Click;
            this.Controls.Add(btnQuitarVehiculo);
        }

        private void RefreshList()
        {
            lstVehiculos.Items.Clear();
            foreach (var v in _garage.Vehiculos)
                lstVehiculos.Items.Add(v); // usa ToString() de Transporte
        }

        private void btnAgregarCoche_Click_1(object sender, EventArgs e)
        {
            var c = new Coche("Toyota", 2020, "ABC-123", 4, "Corolla");
            _garage.Agregar(c);
            RefreshList();
        }

        private void btnAgregarMoto_Click_1(object sender, EventArgs e)
        {
            var m = new Motocicleta("Honda", 2018, "MOTO-01", 2, false);
            _garage.Agregar(m);
            RefreshList();
        }

        private void BtnQuitarVehiculo_Click(object sender, EventArgs e)
        {
            var selVeh = lstVehiculos.SelectedItem as Transporte;
            if (selVeh == null)
            {
                MessageBox.Show("Seleccione un vehículo para quitar");
                return;
            }

            // Confirmación
            var result = MessageBox.Show(
                $"¿Desea quitar {selVeh.Marca} ({selVeh.Año}) del garage?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                _garage.Remover(selVeh);
                RefreshList();
                lblDetalles.Text = "";
                MessageBox.Show("Vehículo eliminado correctamente.");
            }
        }

        private void btnMostrarInfo_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }
            lblDetalles.Text = sel.MostrarInfo();
        }

        private void btnArrancar_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }
            sel.Arrancar();
            lblDetalles.Text = sel.MostrarInfo();
        }

        private void btnAcelerar_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }
            sel.Acelerar(10);
            lblDetalles.Text = sel.MostrarInfo();
        }

        private void btnFrenar_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }
            sel.Detener();
            lblDetalles.Text = sel.MostrarInfo();
        }

        private void btnBocina_Click_1(object sender, EventArgs e)
        {
            var selVeh = lstVehiculos.SelectedItem as Vehiculo;
            if (selVeh == null) { MessageBox.Show("Seleccione un vehículo"); return; }
            MessageBox.Show(selVeh.TocarBocina());
        }

        private void btnReparar_Click_1(object sender, EventArgs e)
        {
            var sel = lstVehiculos.SelectedItem as Transporte;
            if (sel == null) { MessageBox.Show("Seleccione un vehículo"); return; }

            if (sel is IReparable rep)
                MessageBox.Show(rep.Reparar());
            else
                MessageBox.Show("Este vehículo no implementa reparación (IReparable).");
        }

        private void BtnAsignarConductor_Click(object sender, EventArgs e)
        {
            var selVeh = lstVehiculos.SelectedItem as Transporte;
            if (selVeh == null)
            {
                MessageBox.Show("Seleccione un vehículo");
                return;
            }

            string nombre = txtConductor.Text.Trim();
            if (string.IsNullOrEmpty(nombre))
            {
                MessageBox.Show("Escriba el nombre del conductor");
                return;
            }

            Conductor c = new Conductor(nombre, 30); // edad fija
            c.AsignarVehiculo(selVeh);

            MessageBox.Show($"Conductor {c.Nombre} asignado al vehículo {selVeh.MostrarInfo()}");
        }

        private void lstVehiculos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}



